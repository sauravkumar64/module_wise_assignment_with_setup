module.exports={
    userRegister: require("./userController")
}