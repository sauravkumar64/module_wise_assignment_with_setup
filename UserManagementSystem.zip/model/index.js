module.exports = {
  userRegister: require("./userModel"),
};
